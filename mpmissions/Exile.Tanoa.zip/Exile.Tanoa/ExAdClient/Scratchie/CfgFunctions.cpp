class Scratchie {
    class postInitScratchie {file = "ExAdClient\Scratchie\postInit.sqf"; postInit = 1;};
}