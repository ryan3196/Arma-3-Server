class SubMachineGuns
{
	name = "Sub Machine Guns";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"hgun_PDW2000_F",
		"SMG_01_F",
		"SMG_02_F",
		"SMG_05_F"
	};
};