class BipodAttachments
{
	name = "Bipod Attachments";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itembipod_ca.paa";
	items[] =
	{
		"bipod_01_F_blk",
		"bipod_01_F_mtp",
		"bipod_01_F_snd",
		"bipod_02_F_blk",
		"bipod_02_F_hex",
		"bipod_02_F_tan",
		"bipod_03_F_blk",
		"bipod_03_F_oli",
		//Apex
		"bipod_01_F_khk"
	};
};