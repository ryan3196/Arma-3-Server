class PointerAttachments
{
	name = "Pointer Attachments";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"acc_flashlight",
		"acc_pointer_IR"
	};
};