class Shotguns
{
	name = "Shotguns";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"Exile_Weapon_M1014"
	};
};