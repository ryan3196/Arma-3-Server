class Pistols
{
	name = "Pistols";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\handgun_ca.paa";
	items[] =
	{
		"hgun_ACPC2_F",
		"hgun_P07_F",
		"hgun_Pistol_heavy_01_F",
		"hgun_Pistol_heavy_02_F",
		"hgun_Pistol_Signal_F",
		"hgun_Rook40_F",
		"Exile_Weapon_Colt1911",
		"Exile_Weapon_Makarov",
		"Exile_Weapon_Taurus",
		"Exile_Weapon_TaurusGold",
		//Apex
		"hgun_Pistol_01_F",
		"hgun_P07_khk_F",
		"Exile_Weapon_SA61"
	};
};