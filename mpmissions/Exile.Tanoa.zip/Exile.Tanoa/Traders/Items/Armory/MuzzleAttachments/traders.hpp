class MuzzleAttachments
{
	name = "Suppressor Attachments";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
	items[] =
	{
		"muzzle_snds_338_black",
		"muzzle_snds_338_green",
		"muzzle_snds_338_sand",
		"muzzle_snds_93mmg",
		"muzzle_snds_93mmg_tan",
		"muzzle_snds_acp",
		"muzzle_snds_B",
		"muzzle_snds_H",
		"muzzle_snds_H_MG",
		"muzzle_snds_H_SW",
		"muzzle_snds_L",
		"muzzle_snds_M",
		//Apex
		"muzzle_snds_H_khk_F",
		"muzzle_snds_H_snd_F",
		"muzzle_snds_58_blk_F",
		"muzzle_snds_m_khk_F",
		"muzzle_snds_m_snd_F",
		"muzzle_snds_B_khk_F",
		"muzzle_snds_B_snd_F",
		"muzzle_snds_58_wdm_F",
		"muzzle_snds_65_TI_blk_F",
		"muzzle_snds_65_TI_hex_F",
		"muzzle_snds_65_TI_ghex_F",
		"muzzle_snds_H_MG_blk_F",
		"muzzle_snds_H_MG_khk_F"
	};
};