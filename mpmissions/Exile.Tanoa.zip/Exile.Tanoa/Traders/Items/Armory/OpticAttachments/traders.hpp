class OpticAttachments
{
	name = "Scopes";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
	items[] =
	{
		"optic_Aco",
		"optic_ACO_grn",
		"optic_ACO_grn_smg",
		"optic_Aco_smg",
		"optic_AMS",
		"optic_AMS_khk",
		"optic_AMS_snd",
		"optic_Arco",
		"optic_DMS",
		"optic_Hamr",
		"optic_Holosight",
		"optic_Holosight_smg",
		"optic_KHS_blk",
		"optic_KHS_hex",
		"optic_KHS_old",
		"optic_KHS_tan",
		"optic_LRPS",
		"optic_MRCO",
		"optic_MRD",
		"optic_Nightstalker",
		"optic_NVS",
		"optic_SOS",
		"optic_tws",
		"optic_tws_mg",
		"optic_Yorris",
		//Apex
		"optic_Arco_blk_F",
		"optic_Arco_ghex_F",
		"optic_DMS_ghex_F",
		"optic_Hamr_khk_F",
		"optic_ERCO_blk_F",
		"optic_ERCO_khk_F",
		"optic_ERCO_snd_F",
		"optic_SOS_khk_F",
		"optic_LRPS_tna_F",
		"optic_LRPS_ghex_F",
		"optic_Holosight_blk_F",
		"optic_Holosight_khk_F",
		"optic_Holosight_smg_blk_F"
	};
};