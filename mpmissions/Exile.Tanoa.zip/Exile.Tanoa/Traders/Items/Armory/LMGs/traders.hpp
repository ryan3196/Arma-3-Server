class LightMachineGuns
{
	name = "Light Machine Guns";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"arifle_MX_SW_Black_F",
		"arifle_MX_SW_F",
		"LMG_Mk200_F",
		"LMG_Zafir_F",
		"LMG_03_F",
		"Exile_Weapon_RPK",
		"Exile_Weapon_PK",
		"Exile_Weapon_PKP"

		/*
		"MMG_01_hex_F",
		"MMG_01_tan_F",
		"MMG_02_black_F",
		"MMG_02_camo_F",
		"MMG_02_sand_F"
		*/
	};
};