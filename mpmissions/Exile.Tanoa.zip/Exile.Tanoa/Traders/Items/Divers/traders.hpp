class Diving
{
	name = "Diving";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"G_B_Diving",
		"G_O_Diving",
		"G_I_Diving",
		"V_RebreatherB",
		"V_RebreatherIA",
		"V_RebreatherIR",
		"U_I_Wetsuit",
		"U_O_Wetsuit",
		"U_B_Wetsuit"
	};
};