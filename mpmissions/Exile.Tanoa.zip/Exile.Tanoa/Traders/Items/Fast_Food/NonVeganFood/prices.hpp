
	///////////////////////////////////////////////////////////////////////////////
	// Example of Catigory Lable Here
	///////////////////////////////////////////////////////////////////////////////
	
        class Example_Vehicle_Class_Name                                	    { quality = 6; price = 100000; }; 
        class CUP_B_C130J_Cargo_USMC                                            { quality = 6; price = 100000; };
        class CUP_B_C130J_GB                                 	                { quality = 6; price = 100000; };
        