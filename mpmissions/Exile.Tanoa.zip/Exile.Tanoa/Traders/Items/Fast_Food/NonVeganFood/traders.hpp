class NonVeganFood
{
	name = "Non-Vegan Food";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"Exile_Item_CatSharkFilet_Raw",
		"Exile_Item_TunaFilet_Raw",
		"Exile_Item_AlsatianSteak_Raw",
		"Exile_Item_TurtleFilet_Raw",
		"Exile_Item_SheepSteak_Raw",
		"Exile_Item_FinSteak_Raw",
		"Exile_Item_GoatSteak_Raw",
		"Exile_Item_ChickenFilet_Raw",
		"Exile_Item_RoosterFilet_Raw",
		"Exile_Item_MackerelFilet_Raw",
		"Exile_Item_MulletFilet_Raw",
		"Exile_Item_OrnateFilet_Raw",
		"Exile_Item_RabbitSteak_Raw",
		"Exile_Item_SalemaFilet_Raw",
		"Exile_Item_SnakeFilet_Raw"
	};
};