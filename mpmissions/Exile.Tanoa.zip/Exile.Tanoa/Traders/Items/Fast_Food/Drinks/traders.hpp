class Drinks
{
	name = "Drinks";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"Exile_Item_PlasticBottleCoffee",
		"Exile_Item_PowerDrink",
		"Exile_Item_PlasticBottleFreshWater",
		"Exile_Item_Beer",
		"Exile_Item_EnergyDrink",
		"Exile_Item_ChocolateMilk",
		"Exile_Item_MountainDupe",
		"Exile_Item_PlasticBottleEmpty"
	};
};