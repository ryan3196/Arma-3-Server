class Food
{
	name = "Fast Food";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"Exile_Item_EMRE",
		"Exile_Item_GloriousKnakworst",
		"Exile_Item_Surstromming",
		"Exile_Item_SausageGravy",
		"Exile_Item_Catfood",
		"Exile_Item_ChristmasTinner",
		"Exile_Item_BBQSandwich",
		"Exile_Item_MacasCheese",
		"Exile_Item_Dogfood",
		"Exile_Item_BeefParts",
		"Exile_Item_Cheathas",
		"Exile_Item_Noodles",
		"Exile_Item_SeedAstics",
		"Exile_Item_Raisins",
		"Exile_Item_Moobar",
		"Exile_Item_InstantCoffee"

		// Hunted Animals
		// Note: Adding these to the trader will defeat the purpose of hunting!
		/*
		"Exile_Item_SheepSteak_Cooked",
		"Exile_Item_AlsatianSteak_Cooked",
		"Exile_Item_CatSharkFilet_Cooked",
		"Exile_Item_FinSteak_Cooked",
		"Exile_Item_GoatSteak_Cooked",
		"Exile_Item_TurtleFilet_Cooked",
		"Exile_Item_TunaFilet_Cooked",
		"Exile_Item_RabbitSteak_Cooked",
		"Exile_Item_ChickenFilet_Cooked",
		"Exile_Item_RoosterFilet_Cooked",
		"Exile_Item_MulletFilet_Cooked",
		"Exile_Item_SalemaFilet_Cooked",
		"Exile_Item_MackerelFilet_Cooked",
		"Exile_Item_OrnateFilet_Cooked",
		"Exile_Item_SnakeFilet_Cooked",
		"Exile_Item_CatSharkFilet_Raw",
		"Exile_Item_TunaFilet_Raw",
		"Exile_Item_AlsatianSteak_Raw",
		"Exile_Item_TurtleFilet_Raw",
		"Exile_Item_SheepSteak_Raw",
		"Exile_Item_FinSteak_Raw",
		"Exile_Item_GoatSteak_Raw",
		"Exile_Item_ChickenFilet_Raw",
		"Exile_Item_RoosterFilet_Raw",
		"Exile_Item_MackerelFilet_Raw",
		"Exile_Item_MulletFilet_Raw",
		"Exile_Item_OrnateFilet_Raw",
		"Exile_Item_RabbitSteak_Raw",
		"Exile_Item_SalemaFilet_Raw",
		"Exile_Item_SnakeFilet_Raw"
		*/
	};
};