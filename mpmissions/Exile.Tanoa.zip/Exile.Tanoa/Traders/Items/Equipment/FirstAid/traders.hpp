class FirstAid
{
	name = "FirstAid";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"Exile_Item_InstaDoc",
		"Exile_Item_Bandage",
		"Exile_Item_Vishpirin",
		"Exile_Item_Heatpack",
		"Exile_Item_Defibrillator"
	};
};