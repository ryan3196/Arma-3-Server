///////////////////////////////////////////////////////////////////////////////
// Civillian Clothing
///////////////////////////////////////////////////////////////////////////////
class U_C_Journalist { quality = 1; price = 20; };
class U_C_Poloshirt_blue { quality = 1; price = 20; };
class U_C_Poloshirt_burgundy { quality = 1; price = 20; };
class U_C_Poloshirt_salmon { quality = 1; price = 20; };
class U_C_Poloshirt_stripped { quality = 1; price = 20; };
class U_C_Poloshirt_tricolour { quality = 1; price = 20; };
class U_C_Poor_1 { quality = 1; price = 20; };
class U_C_Poor_2 { quality = 1; price = 20; };
class U_C_Poor_shorts_1 { quality = 1; price = 20; };
class U_C_Scientist { quality = 1; price = 20; };
class U_OrestesBody { quality = 1; price = 40; };
class U_Rangemaster { quality = 1; price = 40; };
class U_NikosAgedBody { quality = 1; price = 40; };
class U_NikosBody { quality = 1; price = 40; };
class U_Competitor { quality = 1; price = 40; };

///////////////////////////////////////////////////////////////////////////////
// Soldier Uniforms
///////////////////////////////////////////////////////////////////////////////
class U_B_CombatUniform_mcam { quality = 2; price = 40; };
class U_B_CombatUniform_mcam_tshirt { quality = 2; price = 40; };
class U_B_CombatUniform_mcam_vest { quality = 2; price = 40; };
class U_B_CombatUniform_mcam_worn { quality = 2; price = 40; };
class U_B_CTRG_1 { quality = 2; price = 40; };
class U_B_CTRG_2 { quality = 2; price = 40; };
class U_B_CTRG_3 { quality = 2; price = 40; };
class U_I_CombatUniform { quality = 2; price = 40; };
class U_I_CombatUniform_shortsleeve { quality = 2; price = 40; };
class U_I_CombatUniform_tshirt { quality = 2; price = 40; };
class U_I_OfficerUniform { quality = 2; price = 40; };
class U_O_CombatUniform_ocamo { quality = 2; price = 40; };
class U_O_CombatUniform_oucamo { quality = 2; price = 40; };
class U_O_OfficerUniform_ocamo { quality = 3; price = 80; };
class U_B_SpecopsUniform_sgg { quality = 3; price = 80; };
class U_O_SpecopsUniform_blk { quality = 3; price = 80; };
class U_O_SpecopsUniform_ocamo { quality = 3; price = 80; };
class U_I_G_Story_Protagonist_F { quality = 3; price = 100; };
class Exile_Uniform_Woodland { quality = 3; price = 150; };

///////////////////////////////////////////////////////////////////////////////
// Guerilla Uniforms
///////////////////////////////////////////////////////////////////////////////
class U_C_HunterBody_grn { quality = 2; price = 40; };
class U_IG_Guerilla1_1 { quality = 2; price = 40; };
class U_IG_Guerilla2_1 { quality = 2; price = 60; };
class U_IG_Guerilla2_2 { quality = 2; price = 40; };
class U_IG_Guerilla2_3 { quality = 2; price = 40; };
class U_IG_Guerilla3_1 { quality = 2; price = 40; };
class U_BG_Guerilla2_1 { quality = 2; price = 40; };
class U_IG_Guerilla3_2 { quality = 2; price = 40; };
class U_BG_Guerrilla_6_1 { quality = 2; price = 60; };
class U_BG_Guerilla1_1 { quality = 2; price = 40; };
class U_BG_Guerilla2_2 { quality = 2; price = 40; };
class U_BG_Guerilla2_3 { quality = 2; price = 40; };
class U_BG_Guerilla3_1 { quality = 2; price = 40; };
class U_BG_leader { quality = 3; price = 40; };
class U_IG_leader { quality = 3; price = 40; };
class U_I_G_resistanceLeader_F { quality = 3; price = 100; };

///////////////////////////////////////////////////////////////////////////////
// Ghillie Suits
///////////////////////////////////////////////////////////////////////////////
class U_B_FullGhillie_ard { quality = 4; price = 150; };
class U_B_FullGhillie_lsh { quality = 4; price = 150; };
class U_B_FullGhillie_sard { quality = 4; price = 150; };
class U_B_GhillieSuit { quality = 3; price = 100; };
class U_I_FullGhillie_ard { quality = 4; price = 150; };
class U_I_FullGhillie_lsh { quality = 4; price = 150; };
class U_I_FullGhillie_sard { quality = 4; price = 150; };
class U_I_GhillieSuit { quality = 3; price = 100; };
class U_O_FullGhillie_ard { quality = 6; price = 150; };
class U_O_FullGhillie_lsh { quality = 6; price = 150; };
class U_O_FullGhillie_sard { quality = 6; price = 150; };
class U_O_GhillieSuit { quality = 5; price = 100; };

///////////////////////////////////////////////////////////////////////////////
// Wet Suits
///////////////////////////////////////////////////////////////////////////////
class U_I_Wetsuit { quality = 3; price = 80; };
class U_O_Wetsuit { quality = 3; price = 80; };
class U_B_Wetsuit { quality = 3; price = 80; };
class U_B_survival_uniform { quality = 3; price = 80; };