class Explosives
{
	name = "Explosives";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\cargothrow_ca.paa";
	items[] =
	{
		"HandGrenade",
		"MiniGrenade",
		"B_IR_Grenade",
		"O_IR_Grenade",
		"I_IR_Grenade",
		"1Rnd_HE_Grenade_shell",
		"3Rnd_HE_Grenade_shell",
		"APERSBoundingMine_Range_Mag",
		"APERSMine_Range_Mag",
		"APERSTripMine_Wire_Mag",
		"ClaymoreDirectionalMine_Remote_Mag",
		"DemoCharge_Remote_Mag",
		"IEDLandBig_Remote_Mag",
		"IEDLandSmall_Remote_Mag",
		"IEDUrbanBig_Remote_Mag",
		"IEDUrbanSmall_Remote_Mag",
		"SatchelCharge_Remote_Mag",
		"SLAMDirectionalMine_Wire_Mag",
		"APERSMineDispenser_Mag",
		"TrainingMine_Mag"
	};
};
