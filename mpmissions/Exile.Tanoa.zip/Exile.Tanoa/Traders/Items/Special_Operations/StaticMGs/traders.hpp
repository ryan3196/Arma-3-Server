class StaticMGs
{
	name = "Static Machine Guns";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"O_HMG_01_support_F",
		//"O_HMG_01_support_high_F", // Does not seem to work with HMG01, only the lower version does
		"O_HMG_01_weapon_F"
	};
};