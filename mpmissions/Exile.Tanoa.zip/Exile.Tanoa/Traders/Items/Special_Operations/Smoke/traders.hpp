class Smokes
{
	name = "Smokes";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"SmokeShell",
		"SmokeShellBlue",
		"SmokeShellGreen",
		"SmokeShellOrange",
		"SmokeShellPurple",
		"SmokeShellRed",
		"SmokeShellYellow",
		"1Rnd_Smoke_Grenade_shell",
		"1Rnd_SmokeBlue_Grenade_shell",
		"1Rnd_SmokeGreen_Grenade_shell",
		"1Rnd_SmokeOrange_Grenade_shell",
		"1Rnd_SmokePurple_Grenade_shell",
		"1Rnd_SmokeRed_Grenade_shell",
		"1Rnd_SmokeYellow_Grenade_shell",
		"3Rnd_Smoke_Grenade_shell",
		"3Rnd_SmokeBlue_Grenade_shell",
		"3Rnd_SmokeGreen_Grenade_shell",
		"3Rnd_SmokeOrange_Grenade_shell",
		"3Rnd_SmokePurple_Grenade_shell",
		"3Rnd_SmokeRed_Grenade_shell",
		"3Rnd_SmokeYellow_Grenade_shell"
	};
};