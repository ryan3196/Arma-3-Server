

class Launchers
{
	name = "Launchers";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"launch_B_Titan_F",
		"launch_B_Titan_tna_F",
		"launch_NLAW_F",
		"launch_RPG7_F",
		"launch_RPG32_F",
		"CUP_launch_Igla",
		"CUP_launch_M136",
		"CUP_launch_9K32Strela",
		"CUP_launch_Javelin",
		"CUP_launch_M47",
		"CUP_launch_MAAWS",
		"CUP_launch_MAAWS_Scope",
		"CUP_launch_Metis",
		"CUP_launch_RPG18"
	};
};