//Vanilla_AA
class launch_B_Titan_F { quality = 5; price = 5000; };
class launch_B_Titan_tna_F { quality = 5; price = 5000; };
  
//Vanilla_AT
class launch_NLAW_F { quality = 5; price = 5000; };
class launch_RPG7_F { quality = 5; price = 5000; };
class launch_RPG32_F { quality = 5; price = 5000; };

// CUP_AA
class CUP_launch_Igla { quality = 5; price = 5000; };
class CUP_launch_M136 { quality = 5; price = 5000; };
class CUP_launch_9K32Strela { quality = 5; price = 5000; };

// CUP_AT
class CUP_launch_Javelin { quality = 5; price = 5000; };
class CUP_launch_M47 { quality = 5; price = 5000; };
class CUP_launch_MAAWS { quality = 5; price = 5000; };
class CUP_launch_MAAWS_Scope { quality = 5; price = 5000; };
class CUP_launch_Metis { quality = 5; price = 5000; };
class CUP_launch_RPG18 { quality = 5; price = 5000; };
