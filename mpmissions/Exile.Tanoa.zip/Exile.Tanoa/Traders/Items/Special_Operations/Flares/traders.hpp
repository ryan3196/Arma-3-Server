class Flares
{
	name = "Flares";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"Chemlight_blue",
		"Chemlight_green",
		"Chemlight_red",
		"FlareGreen_F",
		"FlareRed_F",
		"FlareWhite_F",
		"FlareYellow_F",
		"UGL_FlareGreen_F",
		"UGL_FlareRed_F",
		"UGL_FlareWhite_F",
		"UGL_FlareYellow_F",
		"3Rnd_UGL_FlareGreen_F",
		"3Rnd_UGL_FlareRed_F",
		"3Rnd_UGL_FlareWhite_F",
		"3Rnd_UGL_FlareYellow_F"
	};
};