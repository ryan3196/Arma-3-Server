class Navigation
{
	name = "Special Environment";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"B_Parachute",
		"V_RebreatherB",
		"V_RebreatherIA",
		"V_RebreatherIR",
		"Exile_Headgear_GasMask",
		"G_Diving",
		"G_B_Diving",
		"G_O_Diving",
		"G_I_Diving",
		"NVGoggles",
		"NVGoggles_INDEP",
		"NVGoggles_OPFOR",
		"O_NVGoggles_hex_F",
		"O_NVGoggles_urb_F",
		"O_NVGoggles_ghex_F",
		"NVGoggles_tna_F"
	};
};