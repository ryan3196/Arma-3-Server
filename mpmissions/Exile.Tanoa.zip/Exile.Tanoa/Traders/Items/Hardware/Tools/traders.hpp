class Tools
{
	name = "Tools";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"Exile_Item_Matches",
		"Exile_Item_CookingPot",
		"Exile_Item_CanOpener",
		"Exile_Item_Handsaw",
		"Exile_Item_Pliers",
		"Exile_Item_Grinder",
		"Exile_Item_Foolbox",

		/*
		"Exile_Item_CordlessScrewdriver",
		"Exile_Item_FireExtinguisher",
		
		"Exile_Item_OilCanister",
		"Exile_Item_Screwdriver",
		"Exile_Item_Shovel",
		"Exile_Item_SleepingMat",
		"Exile_Item_ToiletPaper",
		"Exile_Item_BurlapSack",
		"Exile_Item_Bullets_556",
		"Exile_Item_Bullets_762",
		"Exile_Item_WeaponParts",
		*/

		"Binocular",
		"Rangefinder",
		/*
		"Laserdesignator",
		"Laserdesignator_02",
		"Laserdesignator_03",
		*/

		"ItemGPS",
		"ItemMap",
		"ItemCompass",
		"ItemRadio",
		"ItemWatch",
		"MineDetector",
		"Exile_Item_Hammer",
		"Exile_Item_Wrench",
		"Exile_Item_XM8",
		"Exile_Item_ZipTie"
	};
};