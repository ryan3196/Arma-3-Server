class Hardware
{
	name = "Hardware";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{

		"Exile_Item_DuctTape",
		"Exile_Item_ExtensionCord",
		"Exile_Item_FuelCanisterEmpty",
		"Exile_Item_JunkMetal",
		"Exile_Item_LightBulb",
		"Exile_Item_MetalBoard",
		"Exile_Item_MetalPole",
		"Exile_Item_SafeKit",
		"Exile_Item_CamoTentKit",
		"Exile_Item_CodeLock",
		"Exile_Item_MetalScrews"

		/*
		--Not for Sale--
		"Exile_Item_MetalWire",
		"Exile_Item_Laptop",
		"Exile_Item_BaseCameraKit",
		"Exile_Item_MetalHedgehogKit",
		"Exile_Item_Cement",
		"Exile_Item_Sand",
		"Exile_Item_MobilePhone",
		--Unused--
		"Exile_Item_SprayCan_Black",
		"Exile_Item_SprayCan_Red",
		"Exile_Item_SprayCan_Green",
		"Exile_Item_SprayCan_White",
		"Exile_Item_SprayCan_Blue",
		"Exile_Item_CordlessScrewdriver",
		"Exile_Item_FireExtinguisher",
		"Exile_Item_OilCanister",
		"Exile_Item_Hammer",
		"Exile_Item_Carwheel",
		"Exile_Item_SleepingMat",
		"Exile_Item_Defibrillator",
		"Exile_Item_Wrench",
		"Exile_Item_Rope"
		*/
	};
};