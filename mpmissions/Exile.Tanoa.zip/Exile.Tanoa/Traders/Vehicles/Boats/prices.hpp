
///////////////////////////////////////////////////////////////////////////////
// Water Craft of all types
///////////////////////////////////////////////////////////////////////////////
class Exile_Boat_WaterScooter		{ quality = 2; price = 800; };
class CUP_B_Zodiac_USMC				  { quality = 4; price = 25000; };
class CUP_B_RHIB_USMC				    { quality = 4; price = 25000; };
class CUP_B_RHIB2Turret_USMC		{ quality = 4; price = 25000; };
class B_G_Boat_Transport_02_F   { quality = 2; price = 2000; };
class O_G_Boat_Transport_02_F   { quality = 2; price = 2000; };
class I_G_Boat_Transport_02_F   { quality = 2; price = 2000; };
class I_C_Boat_Transport_02_F   { quality = 2; price = 2000; };
class C_Boat_Transport_02_F     { quality = 2; price = 2000; };
class Exile_Boat_RHIB           { quality = 2; price = 2000; };

///////////////////////////////////////////////////////////////////////////////
// SDV
///////////////////////////////////////////////////////////////////////////////
class Exile_Boat_SDV_CSAT			  { quality = 2; price = 11000; };
class Exile_Boat_SDV_Digital		{ quality = 2; price = 11000; };
class Exile_Boat_SDV_Grey			  { quality = 2; price = 11000; };

///////////////////////////////////////////////////////////////////////////////
// RUBBER DUCKS
///////////////////////////////////////////////////////////////////////////////
class Exile_Boat_RubberDuck_CSAT	  { quality = 1; price = 500; };
class Exile_Boat_RubberDuck_Digital { quality = 1; price = 500; };
class Exile_Boat_RubberDuck_Orange	{ quality = 1; price = 500; };
class Exile_Boat_RubberDuck_Blue	  { quality = 1; price = 500; };
class Exile_Boat_RubberDuck_Black 	{ quality = 1; price = 500; };

///////////////////////////////////////////////////////////////////////////////
// MOTOR BOATS
///////////////////////////////////////////////////////////////////////////////
class Exile_Boat_MotorBoat_Police	{ quality = 1; price = 700; };
class Exile_Boat_MotorBoat_Orange	{ quality = 1; price = 700; };
class Exile_Boat_MotorBoat_White	{ quality = 1; price = 700; };

///////////////////////////////////////////////////////////////////////////////
// Landing Craft
///////////////////////////////////////////////////////////////////////////////
class Burnes_MK10_1					{ quality = 4; price = 60000; };
