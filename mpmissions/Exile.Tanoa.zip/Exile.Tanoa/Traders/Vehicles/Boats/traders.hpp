

class Boats
{
	name = "Boats";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"Exile_Boat_RubberDuck_CSAT",
		"Exile_Boat_RubberDuck_Digital",
		"Exile_Boat_RubberDuck_Orange",
		"Exile_Boat_RubberDuck_Blue",
		"Exile_Boat_RubberDuck_Black",
		"Exile_Boat_MotorBoat_Police",
		"Exile_Boat_MotorBoat_Orange",
		"Exile_Boat_MotorBoat_White",
		"Exile_Boat_SDV_CSAT",
		"Exile_Boat_SDV_Digital",
		"Exile_Boat_SDV_Grey",
		"Exile_Boat_WaterScooter",
		"Exile_Boat_RHIB",
		"Burnes_MK10_1",
		"CUP_B_RHIB2Turret_USMC"

	};
};
