// Completed by Zat 12-11-17
class Armed_Fixed_Wing
{
	name = "Armed Fixed Wing";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa"; //Nothing needs to be Changed here.
	items[] =
	{
		"CUP_B_F35B_AA_USMC",
		"CUP_B_F35B_CAS_USMC",
		"CUP_B_F35B_LGB_USMC",
		"CUP_B_F35B_AA_BAF",
		"CUP_B_F35B_CAS_BAF",
		"CUP_B_F35B_LGB_BAF",
		"CUP_B_L39_RKT_CZ",
		"CUP_B_L39_BMB_CZ",
		"CUP_B_SU34_LGB_CDF",
		"CUP_B_SU34_AGM_CDF",
		"CUP_B_A10_CAS_USA",
		"CUP_B_A10_AT_USA",
		"CUP_B_AV8B_CAP_USMC",
		"CUP_B_AV8B_GBU12_USMC",
		"CUP_B_AV8B_MK82_USMC",
		"CUP_B_AV8B_AGM_USMC",
		"CUP_B_GR9_CAP_GB",
		"CUP_B_GR9_Mk82_GB",
		"CUP_B_GR9_GBU12_GB",
		"CUP_B_GR9_AGM_GB",
		"CUP_B_Su25_CDF",
		"CUP_B_MV22_USMC_RAMPGUN"
	};
};