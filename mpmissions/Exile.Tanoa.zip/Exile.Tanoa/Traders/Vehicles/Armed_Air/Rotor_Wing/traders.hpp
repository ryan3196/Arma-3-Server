
// Finished by zat 12-11-17
class Armed_Rotor_Wing
	{
		name = "Armed Rotor Wing";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"CUP_B_AH1Z_USMC",
			"CUP_B_AH1Z_Escort_USMC",
			"CUP_B_AH64D_ES_USA",
			"CUP_B_AH64D_MR_USA",
			"CUP_B_AW159_Hellfire_GB",
			"CUP_B_AW159_Cannon_GB",
			"CUP_B_AW159_Hellfire_RN_Grey",
			"CUP_B_AW159_Cannon_RN_Grey",
			"CUP_B_AW159_Hellfire_RN_Blackcat",
			"CUP_B_AW159_Cannon_RN_Blackcat",
			"CUP_B_CH47F_USA",
			"CUP_B_CH47F_VIV_USA",
			"CUP_B_CH47F_GB",
			"CUP_B_CH47F_VIV_GB",
			"CUP_B_MH60S_USMC",
			"CUP_B_Mi24_D_CDF",
			"CUP_B_Mi35_CZ",
			"CUP_B_Mi35_CZ_Des",
			"CUP_B_Mi35_CZ_Ram",
			"CUP_B_Mi35_CZ_Tiger",
			"CUP_B_Mi35_CZ_Dark",
			"CUP_B_Mi35_CZ_Dark",
			"CUP_B_Mi17_CDF",
			"CUP_B_Mi171Sh_ACR",
			"CUP_B_Merlin_HC3_Armed_GB",
			"CUP_B_Merlin_HC3A_Armed_GB",
			"CUP_B_UH1Y_GUNSHIP_USMC",
			"Exile_Chopper_Huey_Armed_Green",
			"Exile_Chopper_Huey_Armed_Desert",
			"CUP_B_UH60M_FFV_US",
			"CUP_B_UH60L_FFV_US",
			"CUP_B_AH6J_Escort_USA",
			"CUP_B_AH6J_AT_USA",
			"CUP_B_AH6J_MP_USA",
			"CUP_B_AH6J_Escort19_USA"
		};
	};