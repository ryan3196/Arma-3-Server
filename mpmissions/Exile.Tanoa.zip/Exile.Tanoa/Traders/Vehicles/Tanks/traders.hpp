

class Tanks
	{
		name = "Tanks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"CUP_B_LAV25_USMC",
			"CUP_B_LAV25M240_USMC",
			"CUP_B_LAV25_HQ_USMC",
			"CUP_B_M1126_ICV_M2_Desert",
			"CUP_B_M1126_ICV_M2_Woodland",
			"CUP_B_M1126_ICV_MK19_Desert",
			"CUP_B_M1126_ICV_MK19_Woodland",
			"CUP_B_M1130_CV_M2_Desert",
			"CUP_B_M1130_CV_M2_Woodland",
			"CUP_B_M1135_ATGMV_Desert",
			"CUP_B_M1135_ATGMV_Woodland",
			"CUP_B_M1128_MGS_Desert",
			"CUP_B_M1128_MGS_Woodland",
			"CUP_B_AAV_USMC",
			"CUP_B_FV432_Bulldog_GB_D",
			"CUP_B_FV432_Bulldog_GB_D_RWS",
			"CUP_B_FV510_GB_D_SLAT",
			"CUP_B_FV510_GB_D",
			"CUP_B_M113_USA",
			"CUP_B_M163_USA",
			"CUP_B_MCV80_GB_D_SLAT",
			"CUP_B_MCV80_GB_D",
			"CUP_B_M2Bradley_USA_D",
			"CUP_B_M2A3Bradley_USA_D",
			"CUP_B_M2A3Bradley_USA_W",
			"CUP_B_M7Bradley_USA_D",
			"CUP_B_M6LineBacker_USA_D",
			"CUP_B_M1A1_Woodland_US_Army",
			"CUP_B_M1A1_DES_US_Army",
			"CUP_B_M1A2_TUSK_MG_US_Army",
			"CUP_B_M1A2_TUSK_MG_DES_US_Army",
			"CUP_B_T72_CDF",
			"CUP_B_T72_CZ",
			"CUP_B_ZSU23_CDF",

			"O_APC_Tracked_02_AA_F",
			"O_APC_Tracked_02_cannon_F",
			"O_MBT_02_cannon_F",
			"I_APC_Wheeled_03_cannon_F",
			"I_MBT_03_cannon_F",
			"I_APC_tracked_03_cannon_F",
			"B_APC_Tracked_01_rcws_F",
			"B_APC_Tracked_01_CRV_F",
			"B_APC_Tracked_01_AA_F",
			"B_MBT_01_cannon_F"
		};
	};