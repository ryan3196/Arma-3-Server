
class UAVs
{
	name = "Unmanned Aerial Vehicles";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\gps_ca.paa";
	items[] =
	{
		"I_UavTerminal",
		"I_UAV_01_backpack_F"
	};
};