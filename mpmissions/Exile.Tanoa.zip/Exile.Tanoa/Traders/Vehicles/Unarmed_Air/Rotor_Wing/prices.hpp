// Completed by: AkToker 12/13/17

///////////////////////////////////////////////////////////////////////////////
// UH-1H Huey
///////////////////////////////////////////////////////////////////////////////
class Exile_Chopper_Huey_Green                                          { quality = 2; price = 21000; };
class Exile_Chopper_Huey_Desert                                         { quality = 2; price = 21000; };

///////////////////////////////////////////////////////////////////////////////
// Hellcat
///////////////////////////////////////////////////////////////////////////////
class Exile_Chopper_Hellcat_Green                                       { quality = 3; price = 27500; };
class Exile_Chopper_Hellcat_FIA                                         { quality = 3; price = 27500; };

///////////////////////////////////////////////////////////////////////////////
// Hummingbird
///////////////////////////////////////////////////////////////////////////////
class Exile_Chopper_Hummingbird_Green                                   { quality = 3; price = 23000; };

///////////////////////////////////////////////////////////////////////////////
// Hummingbird (Civillian)
///////////////////////////////////////////////////////////////////////////////
class Exile_Chopper_Hummingbird_Civillian_Blue                          { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Red                           { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_ION                           { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_BlueLine                      { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Digital                       { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Elliptical                    { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Furious                       { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_GrayWatcher                   { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Jeans                         { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Light                         { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Shadow                        { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Sheriff                       { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Speedy                        { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Sunset                        { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Vrana                         { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Wasp                          { quality = 1; price = 17000; };
class Exile_Chopper_Hummingbird_Civillian_Wave                          { quality = 1; price = 17000; };

///////////////////////////////////////////////////////////////////////////////
// Huron
///////////////////////////////////////////////////////////////////////////////
class Exile_Chopper_Huron_Black                                         { quality = 5; price = 50000; };
class Exile_Chopper_Huron_Green                                         { quality = 5; price = 50000; };

///////////////////////////////////////////////////////////////////////////////
// Mohawk
///////////////////////////////////////////////////////////////////////////////
class Exile_Chopper_Mohawk_FIA                                          { quality = 4; price = 45000; };

///////////////////////////////////////////////////////////////////////////////
// Orca
///////////////////////////////////////////////////////////////////////////////
class Exile_Chopper_Orca_CSAT                                           { quality = 3; price = 28000; };
class Exile_Chopper_Orca_Black                                          { quality = 3; price = 28000; };
class Exile_Chopper_Orca_BlackCustom                                    { quality = 3; price = 28000; };

///////////////////////////////////////////////////////////////////////////////
// Taru
///////////////////////////////////////////////////////////////////////////////
class Exile_Chopper_Taru_Transport_CSAT                                 { quality = 3; price = 17000; };
class Exile_Chopper_Taru_Transport_Black                                { quality = 3; price = 17000; };
class Exile_Chopper_Taru_CSAT                                           { quality = 4; price = 33000; };
class Exile_Chopper_Taru_Black                                          { quality = 4; price = 33000; };
class Exile_Chopper_Taru_Covered_CSAT                                   { quality = 4; price = 43000; };
class Exile_Chopper_Taru_Covered_Black                                  { quality = 4; price = 43000; };

///////////////////////////////////////////////////////////////////////////////
// Cup Helicopters
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// UH-60 Blackhawk
///////////////////////////////////////////////////////////////////////////////
class CUP_B_UH60M_Unarmed_US                                            { quality = 4; price = 40000; };
class CUP_B_UH60L_Unarmed_US                                            { quality = 4; price = 40000; };
class CUP_B_UH60M_Unarmed_FFV_US                                        { quality = 4; price = 40000; }
class CUP_B_UH60L_Unarmed_FFV_US                                        { quality = 4; price = 40000; };
class CUP_B_UH60M_Unarmed_FFV_MEV_US                                    { quality = 4; price = 40000; };
class CUP_B_UH60L_Unarmed_FFV_MEV_US                                    { quality = 4; price = 40000; };

///////////////////////////////////////////////////////////////////////////////
// MH-6J Little bird
///////////////////////////////////////////////////////////////////////////////
class CUP_B_MH6J_USA                                                    { quality = 3; price = 25000; };

///////////////////////////////////////////////////////////////////////////////
// AW-159 Hellcat/Wildcat
///////////////////////////////////////////////////////////////////////////////
class CUP_B_AW159_Unarmed_GB                                             { quality = 4; price = 45000; };
class CUP_B_Wildcat_Unarmed_RN_Blackcat                                  { quality = 4; price = 45000; };

///////////////////////////////////////////////////////////////////////////////
// M-16
///////////////////////////////////////////////////////////////////////////////
class CUP_B_MI6A_CDF                                                      { quality = 4; price = 60000; };
class CUP_B_MI6T_CDF                                                      { quality = 4; price = 60000; };

///////////////////////////////////////////////////////////////////////////////
// Mi-17
///////////////////////////////////////////////////////////////////////////////
class CUP_B_Mi17_VIV_CDF                                                  { quality = 4; price = 50000; };
class CUP_B_Mi17_medevac_CDF                                              { quality = 4; price = 50000; };

///////////////////////////////////////////////////////////////////////////////
// CH-53E Chinook
///////////////////////////////////////////////////////////////////////////////
class CUP_B_CH53E_USMC                                                    { quality = 4; price = 60000; };
class CUP_B_CH53E_VIV_USMC                                                { quality = 4; price = 60000; };
class CUP_B_CH53E_GER                                                     { quality = 4; price = 60000; };
class CUP_B_CH53E_VIV_GER                                                 { quality = 4; price = 60000; };

///////////////////////////////////////////////////////////////////////////////
// HC3 Merlin
///////////////////////////////////////////////////////////////////////////////
class CUP_B_Merlin_HC3_GB                                                 { quality = 4; price = 50000; };
class CUP_B_Merlin_HC3_VIV_GB                                             { quality = 4; price = 50000; };
class CUP_B_Merlin_HC3A_GB                                                { quality = 4; price = 50000; };
class CUP_B_Merlin_HC4_GB                                                 { quality = 4; price = 50000; };

///////////////////////////////////////////////////////////////////////////////
// UH-1Y Venom
///////////////////////////////////////////////////////////////////////////////
class CUP_B_UH1Y_UNA_USMC                                                 { quality = 2; price = 30000; };
class CUP_B_UH1Y_MEV_USMC                                                 { quality = 2; price = 30000; };

///////////////////////////////////////////////////////////////////////////////
// AH-6X
///////////////////////////////////////////////////////////////////////////////
class CUP_B_AH6X_USA                                                      { quality = 3; price = 25000; };

///////////////////////////////////////////////////////////////////////////////
// SA-330 Puma
///////////////////////////////////////////////////////////////////////////////
class CUP_B_SA330_Puma_HC1_BAF                                            { quality = 3; price = 35000; };
class CUP_B_SA330_Puma_HC2_BAF                                            { quality = 3; price = 35000; };
