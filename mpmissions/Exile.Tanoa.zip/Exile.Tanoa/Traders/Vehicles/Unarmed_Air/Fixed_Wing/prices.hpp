// Completed by: AkToker 12/8/17
///////////////////////////////////////////////////////////////////////////////
// Cessna
///////////////////////////////////////////////////////////////////////////////
class Exile_Plane_Cessna                                       { quality = 1; price = 16500; };

///////////////////////////////////////////////////////////////////////////////
// An-2
///////////////////////////////////////////////////////////////////////////////
class Exile_Plane_AN2_Green                                    { quality = 2; price = 17000; };
class Exile_Plane_AN2_White                                    { quality = 2; price = 17000; };
class Exile_Plane_AN2_Stripe                                   { quality = 2; price = 17000; };
class Exile_Plane_Ceasar										{ quality = 2; price = 17000; };
class Exile_Plane_BlackfishInfantry								{ quality = 4; price = 200000; };
class Exile_Plane_BlackfishVehicle								{ quality = 4; price = 250000; };

///////////////////////////////////////////////////////////////////////////////
// Cup Planes
///////////////////////////////////////////////////////////////////////////////
class CUP_B_C130J_USMC                                	       { quality = 3; price = 100000; };
class CUP_B_C130J_Cargo_USMC                                   { quality = 3; price = 100000; };
class CUP_B_C130J_GB                                 	         { quality = 3; price = 100000; };
class CUP_B_C130J_Cargo_GB                                     { quality = 3; price = 100000; };
class CUP_B_MV22_USMC                                          { quality = 4; price = 150000; };
class CUP_B_MV22_VIV_USMC                                      { quality = 4; price = 150000; };
