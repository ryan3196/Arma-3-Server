

class MRAP
	{
		name = "MRAPs";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Car_BRDM2_HQ",
			"CUP_B_BRDM2_HQ_CDF",
			"CUP_B_BRDM2_HQ_CZ",
			"CUP_B_BRDM2_HQ_Des",
			"CUP_B_BRDM2_CDF",
			"CUP_B_BRDM2_ATGM_CDF",
			"CUP_B_BRDM2_CZ",
			"CUP_B_BTR60_CDF",
			"CUP_B_BMP2_CDF",
			"CUP_B_BMP_HQ_CDF",
			"CUP_B_BMP2_CZ_Des",
			"CUP_B_BMP_HQ_CZ",
			"CUP_B_BMP_HQ_CZ_Des",
			"CUP_B_BMP2_AMB_CZ_Des",
			"CUP_B_Dingo_CZ_Wdl",
			"CUP_B_Dingo_CZ_Des",
			"CUP_B_Dingo_GER_Des",
			"CUP_B_Dingo_GL_CZ_Des",
			"CUP_B_Dingo_GL_GER_Des",
			"CUP_B_Mastiff_HMG_GB_W",
			"CUP_B_Mastiff_GMG_GB_W",
			"CUP_B_Mastiff_LMG_GB_W",
			"CUP_B_Ridgback_HMG_GB_W",
			"CUP_B_Ridgback_GMG_GB_W",
			"CUP_B_Ridgback_LMG_GB_W",
			"CUP_B_Wolfhound_HMG_GB_W",
			"CUP_B_Wolfhound_GMG_GB_W",
			"CUP_B_Wolfhound_LMG_GB_W",
			"CUP_B_RG31_M2_USMC",
			"CUP_B_RG31_M2_OD_USMC",
			"CUP_B_RG31_M2_GC_USMC",
			"CUP_B_RG31_Mk19_USMC",
			"CUP_B_RG31_Mk19_OD_USMC",
			"CUP_B_RG31E_M2_USMC",
			"CUP_B_M1133_MEV_Desert",
			"CUP_B_M1133_MEV_Woodland",
			"CUP_B_M1133_MEV_Woodland_Slat",
			"Exile_Car_Ifrit",
			"Exile_Car_Hunter",
			"Exile_Car_Strider",

			"O_T_MRAP_02_hmg_ghex_F",
			"O_T_MRAP_02_gmg_ghex_F",
			"O_T_UGV_01_rcws_ghex_F",
			"B_MRAP_01_gmg_F",
			"B_MRAP_01_hmg_F",
			"B_UGV_01_rcws_F",
			"B_T_MRAP_01_gmg_F",
			"B_T_MRAP_01_hmg_F",
			"I_MRAP_03_hmg_F",
			"I_MRAP_03_gmg_F",
			"I_UGV_01_rcws_F"
		};
	};