

class Armed_Ground
	{
		name = "Armed Ground";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Car_Offroad_Armed_Guerilla01",
			"Exile_Car_Offroad_Armed_Guerilla02",
			"Exile_Car_SUV_Armed_Black",
			"Exile_Car_BTR40_MG_Green",
			"Exile_Car_BTR40_MG_Camo",
			"Exile_Car_HMMWV_M134_Green",
			"Exile_Car_HMMWV_M2_Desert",
			"CUP_B_HMMWV_M2_USMC",
			"CUP_B_HMMWV_M2_USA",
			"CUP_B_HMMWV_M2_GPK_USA",
			"CUP_B_HMMWV_DSHKM_GPK_ACR",
			"CUP_B_HMMWV_Crows_M2_USA",
			"CUP_B_HMMWV_SOV_USA",
			"CUP_B_HMMWV_MK19_USMC",
			"CUP_B_HMMWV_MK19_USA",
			"CUP_B_HMMWV_AGS_GPK_ACR",
			"CUP_B_HMMWV_Crows_MK19_USA",
			"CUP_B_HMMWV_TOW_USMC",
			"CUP_B_HMMWV_M1114_USMC",
			"CUP_B_HMMWV_Avenger_USMC",
			"CUP_B_LR_MG_CZ_W",
			"CUP_B_LR_MG_GB_W",
			"CUP_B_LR_Special_CZ_W",
			"CUP_B_LR_Special_Des_CZ_D",
			"CUP_B_LR_Special_GMG_GB_W",
			"CUP_B_LR_Special_GMG_GB_D",
			"CUP_B_LR_Special_M2_GB_W",
			"CUP_B_LR_Special_M2_GB_D",
			"CUP_B_BAF_Coyote_L2A1_D",
			"CUP_B_BAF_Coyote_GMG_W",
			"CUP_B_Jackal2_L2A1_GB_D",
			"CUP_B_Jackal2_GMG_GB_W",
			"CUP_B_UAZ_MG_CDF",
			"CUP_B_UAZ_AGS30_CDF",
			"CUP_B_UAZ_AGS30_ACR",
			"CUP_B_UAZ_SPG9_CDF",
			"CUP_B_UAZ_SPG9_ACR",
			"CUP_B_UAZ_METIS_CDF",
			"CUP_B_UAZ_METIS_ACR",
			"B_T_LSV_01_Armed_black_F",
			"B_T_LSV_01_Armed_olive_F",
		        "O_T_LSV_02_armed_arid_F",
			"O_T_LSV_02_armed_ghex_F",
			"O_T_LSV_02_armed_black_F"
		};
	};
