// Completed by: AkToker 12/10/17

///////////////////////////////////////////////////////////////////////////////
// Prowlers
///////////////////////////////////////////////////////////////////////////////
class B_T_LSV_01_armed_F                                { quality = 4; price = 40000; };
class B_T_LSV_01_armed_CTRG_F                           { quality = 4; price = 40000; };
class B_LSV_01_armed_F                                  { quality = 4; price = 40000; };
class B_LSV_01_armed_olive_F                            { quality = 4; price = 40000; };
class B_LSV_01_armed_sand_F                             { quality = 4; price = 40000; };                      
class B_LSV_01_Armed_black_F                            { quality = 4; price = 40000; };
class B_T_LSV_01_Armed_olive_F                          { quality = 4; price = 40000; };
class B_T_LSV_01_Armed_sand_F                           { quality = 4; price = 40000; };
class B_T_LSV_01_Armed_black_F                          { quality = 4; price = 40000; };
  
///////////////////////////////////////////////////////////////////////////////
// Qilins
///////////////////////////////////////////////////////////////////////////////
class O_T_LSV_02_armed_viper_F                           { quality = 4; price = 40000; };
class O_T_LSV_02_armed_F                                 { quality = 4; price = 40000; };
class O_LSV_02_armed_viper_F                             { quality = 4; price = 40000; };
class O_LSV_02_armed_F                                   { quality = 4; price = 40000; };
class O_T_LSV_02_armed_black_F                           { quality = 4; price = 40000; };
class O_T_LSV_02_armed_ghex_F                            { quality = 4; price = 40000; };
class O_T_LSV_02_armed_arid_F                            { quality = 4; price = 40000; };
class O_LSV_02_armed_black_F                             { quality = 4; price = 40000; };
class O_LSV_02_armed_ghex_F                              { quality = 4; price = 40000; };
class O_LSV_02_armed_arid_F                              { quality = 4; price = 40000; };
 
///////////////////////////////////////////////////////////////////////////////
// Offroad (Armed)
///////////////////////////////////////////////////////////////////////////////
class Exile_Car_Offroad_Armed_Guerilla01                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla02                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla03                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla04                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla05                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla06                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla07                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla08                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla09                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla10                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla11                  { quality = 4; price = 30000; };
class Exile_Car_Offroad_Armed_Guerilla12                  { quality = 4; price = 30000; };
class I_G_Offroad_01_F                                    { quality = 4; price = 30000; };


///////////////////////////////////////////////////////////////////////////////
// SUV (Armed)
///////////////////////////////////////////////////////////////////////////////
class Exile_Car_SUV_Armed_Black                           { quality = 4; price = 35000; };

///////////////////////////////////////////////////////////////////////////////
// BTR40
///////////////////////////////////////////////////////////////////////////////
class Exile_Car_BTR40_MG_Green                            { quality = 4; price = 35000; };
class Exile_Car_BTR40_MG_Camo                             { quality = 4; price = 35000; };

///////////////////////////////////////////////////////////////////////////////
// HMMWV
///////////////////////////////////////////////////////////////////////////////
class Exile_Car_HMMWV_M134_Green                          { quality = 4; price = 35000; };
class Exile_Car_HMMWV_M134_Desert                         { quality = 4; price = 35000; };
class Exile_Car_HMMWV_M2_Green                            { quality = 4; price = 35000; };
class Exile_Car_HMMWV_M2_Desert                           { quality = 4; price = 35000; };
class CUP_B_HMMWV_M2_USMC                                 { quality = 4; price = 35000; };
class CUP_B_HMMWV_M2_USA                                  { quality = 4; price = 35000; };
class CUP_B_HMMWV_M2_GPK_USA                              { quality = 4; price = 35000; };
class CUP_B_HMMWV_M2_GPK_ACR                              { quality = 4; price = 35000; };
class CUP_B_HMMWV_DSHKM_GPK_ACR                           { quality = 4; price = 40000; };
class CUP_B_HMMWV_Crows_M2_USA                            { quality = 4; price = 45000; };
class CUP_B_HMMWV_SOV_USA                                 { quality = 4; price = 38000; };
class CUP_B_HMMWV_MK19_USMC                               { quality = 4; price = 40000; };
class CUP_B_HMMWV_MK19_USA                                { quality = 4; price = 40000; };
class CUP_B_HMMWV_AGS_GPK_ACR                             { quality = 4; price = 45000; };
class CUP_B_HMMWV_Crows_MK19_USA                          { quality = 4; price = 50000; };
class CUP_B_HMMWV_TOW_USMC                                { quality = 4; price = 45000; };
class CUP_B_HMMWV_TOW_USA                                 { quality = 4; price = 45000; };
class CUP_B_HMMWV_M1114_USMC                              { quality = 4; price = 35000; };
class CUP_B_HMMWV_Avenger_USMC                            { quality = 4; price = 60000; };
class CUP_B_HMMWV_Avenger_USA                             { quality = 4; price = 60000; };

///////////////////////////////////////////////////////////////////////////////
// Land Rover
///////////////////////////////////////////////////////////////////////////////
class CUP_B_LR_MG_CZ_W                                    { quality = 4; price = 35000; };
class CUP_B_LR_MG_GB_W                                    { quality = 4; price = 35000; };
class CUP_B_LR_Special_CZ_W                               { quality = 4; price = 45000; };
class CUP_B_LR_Special_Des_CZ_D                           { quality = 4; price = 45000; };
class CUP_B_LR_Special_GMG_GB_W                           { quality = 4; price = 45000; };
class CUP_B_LR_Special_GMG_GB_D                           { quality = 4; price = 45000; };
class CUP_B_LR_Special_M2_GB_W                            { quality = 4; price = 40000; };
class CUP_B_LR_Special_M2_GB_D                            { quality = 4; price = 40000; };

///////////////////////////////////////////////////////////////////////////////
// BAF Coyote / Jackal
///////////////////////////////////////////////////////////////////////////////
class CUP_B_BAF_Coyote_L2A1_D                             { quality = 4; price = 45000; };
class CUP_B_BAF_Coyote_L2A1_W                             { quality = 4; price = 45000; };
class CUP_B_BAF_Coyote_GMG_D                              { quality = 4; price = 50000; };
class CUP_B_BAF_Coyote_GMG_W                              { quality = 4; price = 50000; };
class CUP_B_Jackal2_L2A1_GB_D                             { quality = 4; price = 45000; };
class CUP_B_Jackal2_L2A1_GB_W                             { quality = 4; price = 45000; };
class CUP_B_Jackal2_GMG_GB_D                              { quality = 4; price = 50000; };
class CUP_B_Jackal2_GMG_GB_W                              { quality = 4; price = 50000; };

///////////////////////////////////////////////////////////////////////////////
// UAZ
///////////////////////////////////////////////////////////////////////////////
class CUP_B_UAZ_MG_CDF                                    { quality = 4; price = 30000; };
class CUP_B_UAZ_MG_ACR                                    { quality = 4; price = 30000; };
class CUP_B_UAZ_AGS30_CDF                                 { quality = 4; price = 35000; };
class CUP_B_UAZ_AGS30_ACR                                 { quality = 4; price = 35000; };
class CUP_B_UAZ_SPG9_CDF                                  { quality = 4; price = 40000; };
class CUP_B_UAZ_SPG9_ACR                                  { quality = 4; price = 40000; };
class CUP_B_UAZ_METIS_CDF                                 { quality = 4; price = 42000; };
class CUP_B_UAZ_METIS_ACR                                 { quality = 4; price = 42000; };
